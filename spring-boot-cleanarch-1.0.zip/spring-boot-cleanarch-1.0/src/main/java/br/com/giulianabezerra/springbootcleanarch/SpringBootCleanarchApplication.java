package br.com.giulianabezerra.springbootcleanarch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCleanarchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCleanarchApplication.class, args);
	}

}
